from pathlib import Path

new_templates = {
    'landing.html': '''{% extends 'base.html' %}
{% block title %}SecurePay AI — UPI Fraud Protection{% endblock %}
{% block styles %}
<style>
    :root { color-scheme: dark; color: #e2e8f0; background: #050a16; font-family: 'Inter', system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: radial-gradient(circle at top, rgba(56, 189, 248, 0.16), transparent 30%), linear-gradient(180deg, #020617 0%, #09111f 100%); overflow-x: hidden; }
    .hero { display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 28px; align-items: center; margin-top: 0; padding: 34px; border-radius: 32px; background: rgba(12, 18, 32, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); box-shadow: 0 40px 110px rgba(0, 0, 0, 0.22); }
    .hero h1 { margin: 0; font-size: clamp(3rem, 5vw, 4.8rem); line-height: 0.98; }
    .hero p { margin: 24px 0 0; color: #cbd5e1; line-height: 1.8; max-width: 560px; }
    .cta-row { margin-top: 32px; display: flex; flex-wrap: wrap; gap: 16px; }
    .button { display: inline-flex; align-items: center; justify-content: center; padding: 16px 24px; border-radius: 18px; font-weight: 700; text-decoration: none; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .button-primary { background: #38bdf8; color: #020617; }
    .button-secondary { border: 1px solid rgba(56, 189, 248, 0.38); color: #38bdf8; background: transparent; }
    .button:hover { transform: translateY(-2px); box-shadow: 0 20px 40px rgba(56, 189, 248, 0.22); }
    .hero-stats { margin-top: 36px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 18px; }
    .stat { padding: 22px; border-radius: 24px; background: rgba(255,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.12); }
    .stat strong { display: block; margin-bottom: 8px; font-size: 1.1rem; color: #cbd5e1; }
    .stat span { color: #94a3b8; }
    .visual-panel { position: relative; min-height: 520px; border-radius: 32px; padding: 28px; background: radial-gradient(circle at top, rgba(56, 189, 248, 0.16), transparent 32%), linear-gradient(180deg, #08101f 0%, #020617 100%); overflow: hidden; }
    .visual-panel::before { content: ''; position: absolute; inset: 0; background: radial-gradient(circle at center, rgba(56, 189, 248, 0.1), transparent 34%); }
    .visual-card { position: relative; z-index: 1; width: 100%; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: flex-start; gap: 18px; padding: 28px; border-radius: 28px; background: rgba(15, 23, 42, 0.92); border: 1px solid rgba(148, 163, 184, 0.16); }
    .visual-card h2 { margin: 0; font-size: 1.55rem; }
    .visual-card p { margin: 0; color: #94a3b8; line-height: 1.8; }
    .features { margin-top: 40px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; }
    .feature { padding: 24px; border-radius: 24px; background: rgba(255,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.12); }
    .feature h3 { margin-top: 0; font-size: 1.05rem; }
    .feature p { margin: 14px 0 0; color: #94a3b8; line-height: 1.8; }
    .trust { margin-top: 44px; display: flex; flex-wrap: wrap; gap: 14px; justify-content: center; }
    .trust span { padding: 14px 18px; border-radius: 16px; background: rgba(255,255,255,0.04); border: 1px solid rgba(148, 163, 184, 0.12); color: #94a3b8; font-size: 0.92rem; }
    @media (max-width: 980px) { .hero { grid-template-columns: 1fr; } .hero-stats { grid-template-columns: 1fr; } .features { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <div>
        <h1>Protect every UPI payment with hybrid machine learning.</h1>
        <p>SecurePay AI combines deep learning, random forest scoring, and transaction heuristics to catch fraud before it clears.</p>
        <div class="cta-row">
            <a class="button button-primary" href="/home">Go to Product</a>
            <a class="button button-secondary" href="/login">Login Securely</a>
        </div>
        <div class="hero-stats">
            <div class="stat"><strong>1,045,230</strong><span>Transactions scored</span></div>
            <div class="stat"><strong>18,512</strong><span>Potential fraud alerts</span></div>
            <div class="stat"><strong>98.4%</strong><span>Model confidence</span></div>
        </div>
    </div>
    <div class="visual-panel">
        <div class="visual-card">
            <h2>Security operations</h2>
            <p>Real-time analytics, case review, and payment verification in one sleek platform.</p>
        </div>
    </div>
</section>
<section class="features">
    <div class="feature"><h3>Instant fraud scoring</h3><p>Every transaction is analyzed in milliseconds so payments can be approved or blocked fast.</p></div>
    <div class="feature"><h3>Hybrid detection</h3><p>Combines statistical models, deep signatures, and contextual payment patterns.</p></div>
    <div class="feature"><h3>Audit-ready logs</h3><p>All verification events are recorded in the backend database for compliance and analysis.</p></div>
    <div class="feature"><h3>Designed for SaaS</h3><p>Landing, home, login, MFA, and dashboard flows mimic a real enterprise application experience.</p></div>
    <div class="feature"><h3>Risk-based actions</h3><p>Safe, suspicious, and fraud verdicts are generated with actionable scoring and notes.</p></div>
    <div class="feature"><h3>Secure workflow</h3><p>The platform guides users through each step so the app feels intuitive and polished.</p></div>
</section>
<div class="trust"><span>SBI</span><span>HDFC</span><span>ICICI</span><span>Axis</span><span>PCI DSS</span></div>
{% endblock %}
''',
    'home.html': '''{% extends 'base.html' %}
{% block title %}SecurePay AI — Product Home{% endblock %}
{% block styles %}
<style>
    :root { color-scheme: dark; color: #e2e8f0; background: #030712; font-family: 'Inter', system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.18), transparent 26%), linear-gradient(180deg, #020617 0%, #07131f 100%); }
    .page { width: min(1180px, 100%); margin: 0 auto; padding: 32px 24px; }
    .hero { margin-top: 0; padding: 34px; border-radius: 32px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 28px; }
    .hero h2 { margin: 0; font-size: clamp(2.8rem, 4vw, 3.8rem); line-height: 1.02; }
    .hero p { margin: 22px 0 0; color: #cbd5e1; line-height: 1.8; max-width: 540px; }
    .hero-actions { margin-top: 32px; display: flex; flex-wrap: wrap; gap: 16px; }
    .button-primary, .button-secondary { display: inline-flex; align-items: center; justify-content: center; padding: 16px 26px; border-radius: 18px; font-weight: 700; text-decoration: none; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    .button-primary { background: #38bdf8; color: #020617; }
    .button-secondary { border: 1px solid rgba(56, 189, 248, 0.4); color: #38bdf8; background: transparent; }
    .button-primary:hover, .button-secondary:hover { transform: translateY(-2px); box-shadow: 0 18px 40px rgba(56, 189, 248, 0.22); }
    .hero-panel { display: grid; gap: 18px; }
    .panel-card { padding: 24px; border-radius: 28px; background: rgba(255,255,255,0.04); border: 1px solid rgba(148, 163, 184, 0.14); }
    .panel-card strong { display: block; margin-bottom: 10px; color: #cbd5e1; }
    .panel-card p { margin: 0; color: #94a3b8; line-height: 1.7; }
    .kpi-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 18px; margin-top: 28px; }
    .kpi { padding: 24px; border-radius: 28px; background: rgba(15,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.14); }
    .kpi h3 { margin: 0 0 12px; color: #94a3b8; font-size: 0.95rem; }
    .kpi p { margin: 0; font-size: 2rem; font-weight: 700; }
    .features { margin-top: 36px; display: grid; gap: 20px; grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .feature-card { padding: 24px; border-radius: 28px; background: rgba(255,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.12); }
    .feature-card h3 { margin-top: 0; }
    .feature-card p { margin: 12px 0 0; color: #94a3b8; line-height: 1.75; }
    @media (max-width: 960px) { .hero { grid-template-columns: 1fr; } .kpi-grid { grid-template-columns: 1fr; } .features { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <div>
        <h2>Next-generation UPI fraud detection for completed payments.</h2>
        <p>Explore the product experience, then login and verify transaction legitimacy using our hybrid scoring engine.</p>
        <div class="hero-actions">
            <a class="button-primary" href="/login">Secure Login</a>
            <a class="button-secondary" href="/verify">Verify Payments</a>
        </div>
    </div>
</section>
<div class="kpi-grid">
    <div class="kpi"><h3>Secure sessions</h3><p>100%</p></div>
    <div class="kpi"><h3>Step-by-step flow</h3><p>5</p></div>
    <div class="kpi"><h3>Real-time scoring</h3><p>Instant</p></div>
</div>
<div class="features">
    <div class="feature-card"><h3>Guided onboarding</h3><p>Landing page → home page → login → MFA → dashboard. Each step is designed as part of a real SaaS workflow.</p></div>
    <div class="feature-card"><h3>Realistic data flow</h3><p>Use transaction details, UPI IDs, and screenshot evidence to validate payments in the verify page.</p></div>
    <div class="feature-card"><h3>Decision support</h3><p>Model confidence, notes, and fraud verdicts help users act on suspected payments.</p></div>
</div>
{% endblock %}
''',
    'login.html': '''{% extends 'base.html' %}
{% block title %}Login — SecurePay AI{% endblock %}
{% block styles %}
<style>
    :root { color-scheme: dark; color: #e2e8f0; background: #020617; font-family: 'Inter', system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.18), transparent 28%), linear-gradient(180deg, #020617 0%, #091018 100%); display: grid; place-items: center; padding: 24px; }
    .page-shell { width: min(520px, 100%); }
    .auth-card { width: 100%; padding: 34px; border-radius: 28px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); box-shadow: 0 34px 90px rgba(0, 0, 0, 0.22); }
    .brand { display: flex; align-items: center; gap: 14px; margin-bottom: 24px; }
    .brand-dot { width: 42px; height: 42px; border-radius: 14px; background: linear-gradient(135deg, #38bdf8, #7c3aed); display: grid; place-items: center; color: #020617; font-weight: 900; }
    .brand-title { margin: 0; font-size: 1.45rem; }
    .brand-subtitle { margin: 6px 0 0; color: #94a3b8; font-size: 0.95rem; }
    h1 { margin: 0 0 14px; font-size: 2.2rem; }
    .subtitle { margin: 0; color: #94a3b8; line-height: 1.75; }
    .step-label { margin-top: 20px; display: inline-flex; align-items: center; gap: 10px; color: #38bdf8; font-weight: 700; font-size: 0.95rem; }
    label { display: block; margin-top: 20px; margin-bottom: 8px; color: #cbd5e1; font-size: 0.95rem; }
    input { width: 100%; padding: 14px 16px; border: 1px solid rgba(148, 163, 184, 0.2); border-radius: 16px; background: #111827; color: #e2e8f0; font-size: 1rem; }
    button { width: 100%; margin-top: 28px; padding: 16px 18px; border: none; border-radius: 18px; background: #38bdf8; color: #020617; font-size: 1rem; font-weight: 700; cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    button:hover { transform: translateY(-1px); box-shadow: 0 18px 36px rgba(56, 189, 248, 0.25); }
    .message { margin-top: 20px; padding: 14px 16px; border-radius: 16px; background: rgba(248, 113, 113, 0.14); border: 1px solid rgba(248, 113, 113, 0.25); color: #fecaca; }
    .footer { margin-top: 24px; color: #94a3b8; font-size: 0.95rem; text-align: center; }
    .footer a { color: #38bdf8; text-decoration: none; }
</style>
{% endblock %}
{% block content %}
<div class="page-shell">
    <div class="auth-card">
        <div class="brand"><div class="brand-dot">SP</div><div><p class="brand-title">SecurePay AI</p><p class="brand-subtitle">Hybrid UPI fraud detection</p></div></div>
        <p class="step-label">Step 3 of 5 — Login securely to continue</p>
        <h1>Access your dashboard</h1>
        <p class="subtitle">Enter your credentials to continue the secure transaction verification flow.</p>
        {% if message %}
            <div class="message">{{ message }}</div>
        {% endif %}
        <form method="post" action="/login">
            <label for="username">Username</label>
            <input id="username" name="username" type="text" placeholder="admin" required autofocus>
            <label for="password">Password</label>
            <input id="password" name="password" type="password" placeholder="Enter your password" required>
            <button type="submit">Continue</button>
        </form>
        <div class="footer">Default credentials: admin / admin123</div>
        <div class="footer"><a href="/home">Back to product home</a></div>
    </div>
</div>
{% endblock %}
''',
    'mfa.html': '''{% extends 'base.html' %}
{% block title %}Multi-Factor Authentication — SecurePay AI{% endblock %}
{% block styles %}
<style>
    :root { color-scheme: dark; color: #e2e8f0; background: #04070f; font-family: 'Inter', system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.14), transparent 26%), linear-gradient(180deg, #06090f 0%, #02040a 100%); }
    .page-shell { width: min(520px, 100%); }
    .panel { width: 100%; padding: 38px; border-radius: 32px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); box-shadow: 0 36px 100px rgba(0, 0, 0, 0.32); }
    .brand { display: flex; align-items: center; gap: 14px; margin-bottom: 24px; }
    .brand-logo { width: 48px; height: 48px; border-radius: 16px; background: linear-gradient(135deg, #38bdf8, #7c3aed); display: grid; place-items: center; font-weight: 900; color: #020617; }
    h1 { margin: 0; font-size: 2rem; line-height: 1.05; }
    p { margin: 12px 0 0; color: #94a3b8; line-height: 1.8; }
    .scanner { margin: 30px 0; height: 220px; border-radius: 28px; background: linear-gradient(180deg, rgba(56, 189, 248, 0.08), rgba(15, 23, 42, 0.88)); border: 1px solid rgba(56, 189, 248, 0.2); display: grid; place-items: center; position: relative; overflow: hidden; }
    .scanner::before { content: ''; position: absolute; inset: 0; background: radial-gradient(circle at center, rgba(56, 189, 248, 0.18), transparent 55%); }
    .scanner .beam { position: absolute; inset: 0; background: linear-gradient(180deg, transparent 46%, rgba(56, 189, 248, 0.24) 50%, transparent 54%); animation: sweep 3s linear infinite; }
    .face { position: relative; width: 120px; height: 120px; border-radius: 50%; border: 3px solid rgba(56, 189, 248, 0.6); display: grid; place-items: center; z-index: 1; }
    .face::before { content: ''; width: 60px; height: 60px; border-radius: 50%; background: rgba(56, 189, 248, 0.18); }
    @keyframes sweep { from { transform: translateY(-100%); } to { transform: translateY(100%); } }
    label { display: block; margin-bottom: 10px; color: #94a3b8; font-size: 0.95rem; }
    input { width: 100%; padding: 16px 18px; border-radius: 16px; border: 1px solid rgba(148, 163, 184, 0.18); background: #0d1726; color: #e2e8f0; font-size: 1rem; }
    button { width: 100%; margin-top: 24px; padding: 16px 18px; border: none; border-radius: 18px; background: #38bdf8; color: #020617; font-weight: 700; cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    button:hover { transform: translateY(-1px); box-shadow: 0 16px 36px rgba(56, 189, 248, 0.28); }
    .note { margin-top: 16px; color: #94a3b8; font-size: 0.95rem; line-height: 1.7; }
</style>
{% endblock %}
{% block content %}
<div class="page-shell">
    <div class="panel">
        <div class="brand">
            <div class="brand-logo">MFA</div>
            <div>
                <h1>Secure multi-factor verification</h1>
                <p>One more step before you reach the SecurePay analytics workspace.</p>
            </div>
        </div>
        <div class="scanner">
            <div class="beam"></div>
            <div class="face"></div>
        </div>
        {% if message %}
            <p style="color:#f9c74f;">{{ message }}</p>
        {% endif %}
        <form method="post" action="/mfa">
            <label for="otp">Authentication code</label>
            <input id="otp" name="otp" type="text" placeholder="123456" required />
            <button type="submit">Verify and continue</button>
        </form>
        <p class="note">For this demo, use code <strong>123456</strong>. In a production app, this would be sent to the user's registered mobile device.</p>
    </div>
</div>
{% endblock %}
''',
    'dashboard.html': '''{% extends 'base.html' %}
{% block title %}SecurePay AI — Dashboard{% endblock %}
{% block styles %}
<style>
    :root {
        --bg: #020617;
        --surface: #111827;
        --panel: #1f2937;
        --text: #e2e8f0;
        --muted: #94a3b8;
        --accent: #38bdf8;
        --success: #22c55e;
        --danger: #ef4444;
        --border: rgba(148, 163, 184, 0.18);
    }
    * { box-sizing: border-box; }
    body {
        margin: 0;
        min-height: 100vh;
        background: radial-gradient(circle at top, rgba(56, 189, 248, 0.12), transparent 35%), linear-gradient(180deg, #020617 0%, #0f172a 90%);
        color: var(--text);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .page { width: 100%; max-width: 1120px; margin: 0 auto; padding: 28px 22px 46px; }
    header {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
    }
    .brand h1 {
        margin: 0;
        font-size: clamp(2rem, 2.4vw, 3rem);
        letter-spacing: -0.04em;
    }
    .brand p {
        margin: 8px 0 0;
        color: var(--muted);
    }
    .nav-actions {
        display: flex;
        gap: 10px;
        align-items: center;
    }
    .nav-actions .user {
        color: var(--muted);
    }
    .nav-actions a {
        padding: 12px 18px;
        border-radius: 14px;
        background: rgba(56, 189, 248, 0.12);
        text-decoration: none;
        color: var(--text);
        border: 1px solid rgba(56, 189, 248, 0.22);
    }
    .hero {
        margin-top: 28px;
        padding: 28px;
        border: 1px solid var(--border);
        border-radius: 24px;
        background: rgba(30, 41, 59, 0.92);
        box-shadow: 0 24px 60px rgba(15, 23, 42, 0.30);
    }
    .hero h2 { margin: 0 0 12px; }
    .hero p { margin: 0; line-height: 1.8; color: var(--muted); }
    .grid { display: grid; gap: 24px; margin-top: 28px; grid-template-columns: 1.3fr 0.7fr; }
    .card { background: var(--panel); border: 1px solid var(--border); border-radius: 24px; padding: 24px; }
    .card h3 { margin-top: 0; margin-bottom: 16px; }
    .card p { color: var(--muted); }
    label { display: block; margin-bottom: 8px; color: var(--muted); font-size: 0.95rem; }
    input, select { width: 100%; padding: 14px 16px; margin-bottom: 18px; border: 1px solid rgba(148, 163, 184, 0.22); border-radius: 14px; background: #0f172a; color: var(--text); font-size: 1rem; }
    button { width: 100%; padding: 14px 16px; border: none; border-radius: 14px; background: var(--accent); color: #020617; font-weight: 700; cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    button:hover { transform: translateY(-1px); box-shadow: 0 14px 30px rgba(56, 189, 248, 0.25); }
    .status-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 20px;
        margin-bottom: 24px;
        border-radius: 20px;
        border: 1px solid rgba(148, 163, 184, 0.16);
        background: rgba(15, 23, 42, 0.85);
    }
    .status-grid { display: grid; gap: 16px; grid-template-columns: repeat(3, minmax(0, 1fr)); margin-top: 24px; }
    .status-card { padding: 18px; border-radius: 18px; background: rgba(30, 41, 59, 0.92); border: 1px solid rgba(148, 163, 184, 0.14); }
    .status-card h4 { margin: 0 0 8px; color: var(--muted); font-size: 0.95rem; }
    .status-card p { margin: 0; font-size: 1.4rem; font-weight: 700; }
    .result-box { min-height: 220px; border-radius: 20px; background: rgba(15, 23, 42, 0.96); padding: 22px; border: 1px solid rgba(148, 163, 184, 0.12); }
    .result-box h4 { margin-top: 0; }
    .result-status { margin: 12px 0; font-size: 1.3rem; font-weight: 700; }
    .result-status.safe { color: var(--success); }
    .result-status.fraud { color: var(--danger); }
    .progress { width: 100%; height: 16px; border-radius: 999px; background: rgba(148, 163, 184, 0.18); overflow: hidden; margin-top: 18px; }
    .progress-bar { height: 100%; width: 0; border-radius: inherit; background: linear-gradient(90deg, #38bdf8, #0284c7); transition: width 0.35s ease; }
    .hint { margin-top: 18px; color: var(--muted); line-height: 1.75; }
    .legal { margin-top: 22px; color: var(--muted); font-size: 0.9rem; line-height: 1.75; }
    @media (max-width: 900px) { .grid { grid-template-columns: 1fr; } .status-grid { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <h2>SecurePay AI dashboard</h2>
    <p>View transaction risk profiles, model insights, and fraud analysis across your UPI payment flow.</p>
</section>
<div class="status-bar">
    <div>
        <h3>Risk detection powered by hybrid ML</h3>
        <p class="nav-actions user">Secure session active</p>
    </div>
    <div class="nav-actions">
        <a href="/verify">Verify Payment</a>
        <a href="/admin">Refresh</a>
    </div>
</div>
<div class="grid">
    <div class="card">
        <h3>Dashboard summary</h3>
        <p>Monitor fraud detection performance and transaction activity in real time.</p>
        <div class="status-grid">
            <div class="status-card"><h4>Reviewed payments</h4><p>14,208</p></div>
            <div class="status-card"><h4>Suspected fraud</h4><p>452</p></div>
            <div class="status-card"><h4>Confidence</h4><p>98.4%</p></div>
        </div>
    </div>
    <div class="card">
        <h3>Risk insights</h3>
        <p>Fraud verdicts are generated from a hybrid model stack and reviewed with transaction metadata.</p>
        <div class="result-box">
            <h4>Latest case</h4>
            <p class="result-status fraud">High risk transaction flagged for manual review.</p>
            <p class="hint">Location mismatch + unusual amount triggered the alert.</p>
        </div>
    </div>
</div>
{% endblock %}
''',
    'verify.html': '''{% extends 'base.html' %}
{% block title %}SecurePay AI — Verify Payment{% endblock %}
{% block styles %}
<style>
    :root { color-scheme: dark; color: #e2e8f0; background: #040b16; font-family: 'Inter', system-ui, sans-serif; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.15), transparent 28%), linear-gradient(180deg, #020617 0%, #08121f 100%); }
    .page { width: min(1180px, 100%); margin: 0 auto; padding: 32px 24px 44px; }
    .hero { margin-top: 28px; padding: 28px; border-radius: 28px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); }
    .hero h2 { margin: 0 0 12px; font-size: 1.9rem; }
    .hero p { margin: 0; color: #cbd5e1; line-height: 1.8; }
    .hero .meta { margin-top: 14px; color: #94a3b8; }
    .grid { margin-top: 24px; display: grid; gap: 24px; grid-template-columns: 1.35fr 0.65fr; }
    .card { padding: 24px; border-radius: 28px; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(148, 163, 184, 0.18); }
    label { display: block; margin-bottom: 10px; color: #94a3b8; font-size: 0.95rem; }
    input, select, textarea { width: 100%; padding: 15px 16px; margin-bottom: 16px; border: 1px solid rgba(148, 163, 184, 0.22); border-radius: 16px; background: #0e172a; color: #e2e8f0; }
    textarea { min-height: 120px; resize: vertical; }
    .stepper { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
    .step { flex: 1; padding: 14px 16px; border-radius: 16px; background: rgba(148, 163, 184, 0.08); color: #94a3b8; text-align: center; font-size: 0.95rem; border: 1px solid rgba(148, 163, 184, 0.14); }
    .step.active { background: rgba(56, 189, 248, 0.14); color: #e2e8f0; border-color: #38bdf8; }
    .step.completed { background: rgba(34, 197, 94, 0.12); color: #a7f3d0; border-color: #22c55e; }
    .step-section { display: none; }
    .step-section.active { display: block; }
    .form-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 16px; }
    .form-actions button { width: auto; min-width: 140px; padding: 14px 18px; border-radius: 16px; border: none; cursor: pointer; font-weight: 700; }
    .form-actions .primary { background: #38bdf8; color: #020617; }
    .form-actions .secondary { background: rgba(255,255,255,0.06); color: #e2e8f0; }
    .summary-field { margin-bottom: 14px; padding: 16px; border-radius: 16px; background: #0f172a; border: 1px solid rgba(148, 163, 184, 0.18); }
    .summary-field strong { display: block; margin-bottom: 8px; color: #94a3b8; }
    .result-card { margin-top: 24px; padding: 24px; border-radius: 24px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(148, 163, 184, 0.18); }
    .result-card h3 { margin-top: 0; }
    .result-status { margin: 16px 0; font-size: 1.25rem; font-weight: 700; }
    .result-status.safe { color: #22c55e; }
    .result-status.fraud { color: #ef4444; }
    .progress { width: 100%; height: 16px; border-radius: 999px; background: rgba(148, 163, 184, 0.18); overflow: hidden; margin-top: 18px; }
    .progress-bar { height: 100%; width: 0; border-radius: inherit; background: linear-gradient(90deg, #38bdf8, #0ea5e9); transition: width 0.35s ease; }
    .hint { margin-top: 16px; color: #94a3b8; line-height: 1.75; }
    .feature-list { display: grid; gap: 12px; margin-top: 20px; }
    .feature-item { display: flex; align-items: center; gap: 12px; padding: 16px; border-radius: 16px; background: rgba(255,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.14); }
    .feature-item span { width: 10px; height: 10px; border-radius: 999px; background: #38bdf8; }
    .feature-item div { color: #cbd5e1; line-height: 1.7; }
    @media (max-width: 880px) { .grid { grid-template-columns: 1fr; } .stepper { flex-direction: column; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <h2>Hybrid fraud detection for completed UPI payments</h2>
    <p>Enter transaction details, review payer information, attach evidence, and run a secure fraud verification check.</p>
    <p class="meta">Model accuracy: {{ model_accuracy if model_accuracy is not none else 'Loading' }}%</p>
</section>
<div class="grid">
    <div class="card">
        <h2>Verification journey</h2>
        {% if not model_ready %}
        <div class="status-box">System is initializing. Please wait a moment and refresh the page.</div>
        {% endif %}
        <div class="stepper">
            <div class="step active" data-step="1">1. Payment</div>
            <div class="step" data-step="2">2. Parties</div>
            <div class="step" data-step="3">3. Evidence</div>
            <div class="step" data-step="4">4. Review</div>
        </div>
        <div class="step-section active" data-step="1">
            <label for="transaction_id">Transaction ID</label>
            <input id="transaction_id" placeholder="TXN123456789" />
            <label for="amount">Amount (INR)</label>
            <input id="amount" type="number" step="0.01" placeholder="1000" />
            <label for="category">Payment Type</label>
            <select id="category">
                <option value="transfer">Transfer</option>
                <option value="payment">Payment</option>
                <option value="refund">Refund</option>
                <option value="withdrawal">Withdrawal</option>
                <option value="deposit">Deposit</option>
                <option value="upi">UPI</option>
                <option value="p2p">P2P</option>
            </select>
        </div>
        <div class="step-section" data-step="2">
            <label for="upi_id">UPI ID</label>
            <input id="upi_id" placeholder="example@bank" />
            <label for="payer_name">Payer Name</label>
            <input id="payer_name" placeholder="Sender name" />
            <label for="payee_name">Payee Name</label>
            <input id="payee_name" placeholder="Receiver name" />
        </div>
        <div class="step-section" data-step="3">
            <label for="remarks">Payment Remarks</label>
            <textarea id="remarks" placeholder="Enter payment note or transaction description"></textarea>
            <label for="screenshot">Screenshot evidence (optional)</label>
            <input id="screenshot" type="file" accept="image/*" />
        </div>
        <div class="step-section" data-step="4">
            <h3>Review before verification</h3>
            <div class="summary-field"><strong>Transaction ID</strong><span id="summary_transaction_id">-</span></div>
            <div class="summary-field"><strong>Amount</strong><span>₹<span id="summary_amount">-</span></span></div>
            <div class="summary-field"><strong>Category</strong><span id="summary_category">-</span></div>
            <div class="summary-field"><strong>UPI ID</strong><span id="summary_upi_id">-</span></div>
            <div class="summary-field"><strong>Payer</strong><span id="summary_payer_name">-</span></div>
            <div class="summary-field"><strong>Payee</strong><span id="summary_payee_name">-</span></div>
            <div class="summary-field"><strong>Remarks</strong><span id="summary_remarks">-</span></div>
        </div>
        <div class="form-actions">
            <button class="secondary" id="prevBtn" type="button" onclick="changeStep(-1)" disabled>Back</button>
            <button class="secondary" id="nextBtn" type="button" onclick="changeStep(1)">Next</button>
            <button class="primary" id="verifyBtn" type="button" onclick="check()" hidden>Verify Payment</button>
        </div>
        <div id="result" class="result-card">
            <h3>Verification outcome</h3>
            <div id="resultText" class="result-status">Use the steps above to review the payment before verification.</div>
            <div class="progress" hidden><div id="scoreBar" class="progress-bar"></div></div>
            <p id="resultHint" class="hint"></p>
        </div>
    </div>
    <div class="card">
        <h2>Verification insights</h2>
        <div class="feature-list">
            <div class="feature-item"><span></span><div>Hybrid ML engine evaluates payment risk across multiple signals.</div></div>
            <div class="feature-item"><span></span><div>Supports UPI details, payer/payee identity, remarks, and screenshot evidence.</div></div>
            <div class="feature-item"><span></span><div>Provides instant Safe/Fraud verdicts and confidence notes.</div></div>
            <div class="feature-item"><span></span><div>Results are logged in the backend for review and analytics.</div></div>
        </div>
    </div>
</div>
{% endblock %}
{% block scripts %}
<script>
    const steps = Array.from(document.querySelectorAll('.step'));
    const stepSections = Array.from(document.querySelectorAll('.step-section'));
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const verifyBtn = document.getElementById('verifyBtn');
    const resultText = document.getElementById('resultText');
    const scoreBar = document.getElementById('scoreBar');
    const progress = document.querySelector('.progress');
    const resultHint = document.getElementById('resultHint');
    let currentStep = 1;

    function showStep(step) {
        stepSections.forEach(section => section.classList.toggle('active', parseInt(section.dataset.step, 10) === step));
        steps.forEach((stepEl, index) => {
            const stepNumber = index + 1;
            stepEl.classList.toggle('active', stepNumber === step);
            stepEl.classList.toggle('completed', stepNumber < step);
        });
        prevBtn.disabled = step === 1;
        nextBtn.hidden = step === 4;
        verifyBtn.hidden = step !== 4;
        if (step === 4) updateReviewSummary();
    }

    function changeStep(direction) {
        currentStep = Math.min(4, Math.max(1, currentStep + direction));
        showStep(currentStep);
    }

    function updateReviewSummary() {
        document.getElementById('summary_transaction_id').textContent = document.getElementById('transaction_id').value || '-';
        document.getElementById('summary_amount').textContent = document.getElementById('amount').value || '-';
        document.getElementById('summary_category').textContent = document.getElementById('category').value || '-';
        document.getElementById('summary_upi_id').textContent = document.getElementById('upi_id').value || '-';
        document.getElementById('summary_payer_name').textContent = document.getElementById('payer_name').value || '-';
        document.getElementById('summary_payee_name').textContent = document.getElementById('payee_name').value || '-';
        document.getElementById('summary_remarks').textContent = document.getElementById('remarks').value || '-';
    }

    function check() {
        verifyBtn.disabled = true;
        verifyBtn.textContent = 'Verifying...';
        resultText.textContent = 'Analyzing payment...';
        resultText.className = 'result-status';
        progress.hidden = true;
        resultHint.textContent = '';

        const formData = new FormData();
        formData.append('transaction_id', document.getElementById('transaction_id').value);
        formData.append('amount', document.getElementById('amount').value);
        formData.append('upi_id', document.getElementById('upi_id').value);
        formData.append('payer_name', document.getElementById('payer_name').value);
        formData.append('payee_name', document.getElementById('payee_name').value);
        formData.append('category', document.getElementById('category').value);
        formData.append('remarks', document.getElementById('remarks').value);
        const screenshotFile = document.getElementById('screenshot').files[0];
        if (screenshotFile) formData.append('screenshot', screenshotFile);

        fetch('/api/check', { method: 'POST', body: formData })
            .then(async response => { const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Unable to analyze payment'); return data; })
            .then(data => {
                const isFraud = data.result === 'FRAUD';
                resultText.textContent = `${data.result} — Score ${data.score.toFixed(4)}`;
                resultText.className = `result-status ${isFraud ? 'fraud' : 'safe'}`;
                scoreBar.style.width = `${Math.min(Math.max(data.score * 100, 4), 100)}%`;
                scoreBar.style.background = isFraud ? '#ef4444' : '#22c55e';
                progress.hidden = false;
                resultHint.textContent = data.note || '';
            })
            .catch(error => {
                resultText.textContent = error.message;
                resultText.className = 'result-status fraud';
                resultHint.textContent = 'Please check the payment details and try again.';
            })
            .finally(() => {
                verifyBtn.disabled = false;
                verifyBtn.textContent = 'Verify Payment';
            });
    }

    showStep(currentStep);
</script>
{% endblock %}
''',
    'admin.html': '''{% extends 'base.html' %}
{% block title %}SecurePay AI — Admin Analytics{% endblock %}
{% block styles %}
<style>
    body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0b1120; color: #e2e8f0; }
    .page { max-width: 1100px; margin: 0 auto; padding: 32px 24px; }
    header { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 16px; }
    .brand h1 { margin: 0; font-size: clamp(2rem, 3vw, 3rem); }
    .brand p { margin: 8px 0 0; color: #94a3b8; }
    .hero { margin-top: 32px; padding: 26px; border-radius: 24px; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(56, 189, 248, 0.16); }
    .hero p { color: #cbd5e1; line-height: 1.75; }
    .kpi-grid { display: grid; gap: 20px; grid-template-columns: repeat(4, minmax(0, 1fr)); margin-top: 24px; }
    .kpi { padding: 24px; border-radius: 24px; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(148, 163, 184, 0.18); }
    .kpi h3 { margin: 0 0 10px; color: #94a3b8; font-size: 0.95rem; }
    .kpi p { margin: 0; font-size: 2rem; font-weight: 700; }
    .section { margin-top: 28px; background: rgba(15, 23, 42, 0.95); border: 1px solid rgba(148, 163, 184, 0.18); border-radius: 24px; padding: 24px; }
    .section h2 { margin-top: 0; }
    .table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    .table th, .table td { padding: 14px 12px; border-bottom: 1px solid rgba(148, 163, 184, 0.12); color: #e2e8f0; }
    .table th { text-align: left; color: #94a3b8; }
    @media (max-width: 900px) { .kpi-grid { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 600px) { .kpi-grid { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <p>This admin panel provides simplified KPI cards and transaction trends for the UPI fraud detection system.</p>
</section>
<div class="kpi-grid">
    <div class="kpi"><h3>Total Transactions</h3><p>{{ total_tx }}</p></div>
    <div class="kpi"><h3>Fraud Rate</h3><p>{{ fraud_rate }}%</p></div>
    <div class="kpi"><h3>Total Amount Analysed</h3><p>₹{{ '%.2f' | format(total_amount) }}</p></div>
    <div class="kpi"><h3>Model Accuracy</h3><p>{{ model_accuracy if model_accuracy is not none else 'N/A' }}%</p></div>
</div>
<div class="section">
    <h2>Fraud / Suspicious Transaction Summary</h2>
    <table class="table">
        <thead>
            <tr><th>Status</th><th>Count</th></tr>
        </thead>
        <tbody>
            <tr><td>Fraud</td><td>{{ fraud_count }}</td></tr>
            <tr><td>Safe</td><td>{{ safe_count }}</td></tr>
            <tr><td>Suspicious</td><td>{{ suspicious_count }}</td></tr>
        </tbody>
    </table>
</div>
{% endblock %}
''',
    'support.html': '''{% extends 'base.html' %}
{% block title %}Support — SecurePay AI{% endblock %}
{% block styles %}
<style>
    :root { font-family: 'Inter', system-ui, sans-serif; color: #e2e8f0; background: #050a16; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: linear-gradient(180deg, #02040a 0%, #070f1c 100%); }
    .page { width: min(1080px, 100%); margin: 0 auto; padding: 28px 22px; }
    header { display: flex; justify-content: space-between; align-items: center; gap: 18px; flex-wrap: wrap; }
    header h1 { margin: 0; font-size: clamp(1.9rem, 3vw, 2.6rem); }
    header a { color: #38bdf8; text-decoration: none; }
    .panel { margin-top: 24px; padding: 28px; border-radius: 28px; background: rgba(15, 23, 42, 0.94); border: 1px solid rgba(56, 189, 248, 0.16); }
    .panel h2 { margin-top: 0; }
    .faq { display: grid; gap: 16px; margin-top: 20px; }
    .faq-item { padding: 20px; border-radius: 22px; background: rgba(8, 14, 27, 0.96); border: 1px solid rgba(148, 163, 184, 0.12); }
    .faq-item h3 { margin: 0 0 10px; }
    .faq-item p { margin: 0; color: #94a3b8; line-height: 1.75; }
    .chatbot { position: fixed; bottom: 28px; right: 28px; width: 64px; height: 64px; border-radius: 50%; background: #38bdf8; display: grid; place-items: center; color: #020617; font-weight: 800; cursor: pointer; box-shadow: 0 20px 40px rgba(56, 189, 248, 0.32); }
    .chat-widget { position: fixed; bottom: 110px; right: 28px; width: 340px; border-radius: 28px; background: rgba(15, 23, 42, 0.96); border: 1px solid rgba(56, 189, 248, 0.18); box-shadow: 0 36px 90px rgba(0,0,0,0.35); overflow: hidden; display: none; }
    .chat-widget.active { display: block; }
    .chat-header { padding: 18px 20px; border-bottom: 1px solid rgba(148, 163, 184, 0.12); display: flex; justify-content: space-between; align-items: center; }
    .chat-header span { color: #94a3b8; }
    .chat-body { padding: 18px 20px; max-height: 260px; overflow-y: auto; display: grid; gap: 14px; }
    .chat-message { padding: 14px 16px; border-radius: 18px; background: rgba(255,255,255,0.05); color: #e2e8f0; }
    .chat-footer { padding: 14px 18px; border-top: 1px solid rgba(148, 163, 184, 0.12); }
    .chat-footer input { width: 100%; padding: 12px 14px; border-radius: 14px; border: 1px solid rgba(148, 163, 184, 0.18); background: #0f1726; color: #e2e8f0; }
</style>
{% endblock %}
{% block content %}
<section class="panel">
    <h2>Need help?</h2>
    <p>Ask Security Bot about account security, incident response, or fraud reporting.</p>
    <div class="faq">
        <div class="faq-item"><h3>How do I reset my API key?</h3><p>Go to Settings &gt; API Keys and click Generate new key.</p></div>
        <div class="faq-item"><h3>Why was a transaction declined?</h3><p>The system may detect a high risk score, unusual payment pattern, or suspicious receiver.</p></div>
        <div class="faq-item"><h3>How do I report fraud?</h3><p>Use the Report Fraud form in the dashboard or contact support directly.</p></div>
    </div>
</section>
<div class="chatbot" onclick="toggleChat()">Bot</div>
<div class="chat-widget" id="chatWidget">
    <div class="chat-header"><span>Security Bot</span><button onclick="toggleChat()">✕</button></div>
    <div class="chat-body" id="chatBody">
        <div class="chat-message">Hello! Ask me about account security, API integration, or transaction alerts.</div>
    </div>
    <div class="chat-footer"><input id="chatInput" placeholder="Type your question..." onkeydown="if(event.key==='Enter') sendChat()"></div>
</div>
{% endblock %}
{% block scripts %}
<script>
    const chatWidget = document.getElementById('chatWidget');
    const chatBody = document.getElementById('chatBody');
    function toggleChat() { chatWidget.classList.toggle('active'); }
    function sendChat() {
        const input = document.getElementById('chatInput');
        if (!input.value.trim()) return;
        const message = document.createElement('div');
        message.className = 'chat-message';
        message.textContent = input.value;
        chatBody.appendChild(message);
        const reply = document.createElement('div');
        reply.className = 'chat-message';
        reply.textContent = 'Security Bot: Please review the FAQ or contact support if you need a secure reset.';
        chatBody.appendChild(reply);
        input.value = '';
        chatBody.scrollTop = chatBody.scrollHeight;
    }
</script>
{% endblock %}
''',
    'transaction.html': '''{% extends 'base.html' %}
{% block title %}Transaction Detail — SecurePay AI{% endblock %}
{% block styles %}
<style>
    :root { font-family: 'Inter', system-ui, sans-serif; color: #e2e8f0; background: #040712; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; background: linear-gradient(180deg, #050914 0%, #02040a 100%); }
    .page { width: min(1120px, 100%); margin: 0 auto; padding: 28px 22px; }
    .topbar { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 18px; }
    .topbar h1 { margin: 0; font-size: clamp(1.8rem, 3vw, 2.6rem); }
    .topbar a { color: #38bdf8; text-decoration: none; }
    .grid { display: grid; gap: 24px; grid-template-columns: 1.3fr 0.7fr; margin-top: 28px; }
    .panel { padding: 26px; border-radius: 28px; background: rgba(15, 23, 42, 0.94); border: 1px solid rgba(56, 189, 248, 0.16); }
    .panel h2 { margin-top: 0; }
    .detail-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 18px; }
    .detail-card { padding: 20px; border-radius: 20px; background: rgba(8, 14, 27, 0.96); border: 1px solid rgba(148, 163, 184, 0.12); }
    .detail-card h3 { margin: 0 0 8px; font-size: 1rem; color: #94a3b8; }
    .detail-card p { margin: 0; font-size: 1.4rem; font-weight: 700; }
    .spider { margin-top: 24px; display: grid; gap: 14px; }
    .spider-bar { display: flex; justify-content: space-between; gap: 14px; align-items: center; }
    .spider-bar span { color: #94a3b8; }
    .spider-fill { width: 100%; height: 12px; border-radius: 999px; background: rgba(148, 163, 184, 0.15); }
    .spider-fill-inner { height: 100%; border-radius: inherit; background: linear-gradient(90deg, #38bdf8, #818cf8); }
    .actions { margin-top: 28px; display: flex; gap: 16px; flex-wrap: wrap; }
    .action-button { flex: 1; min-width: 140px; padding: 16px; border: none; border-radius: 18px; font-weight: 700; cursor: pointer; color: #020617; }
    .action-safe { background: #22c55e; }
    .action-block { background: #ef4444; }
    .action-otp { background: #facc15; }
    .chart { margin-top: 24px; }
    .chart h3 { margin-bottom: 14px; }
    .chart-graph { height: 220px; border-radius: 24px; background: radial-gradient(circle at top, rgba(56, 189, 248, 0.14), transparent 45%), linear-gradient(180deg, #0d1726 0%, #02040a 100%); border: 1px solid rgba(148, 163, 184, 0.16); display: grid; place-items: center; color: #94a3b8; }
    @media (max-width: 900px) { .grid { grid-template-columns: 1fr; } .detail-row { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<div class="page">
    <div class="topbar">
        <h1>Transaction #{{ txn_id }}</h1>
        <a href="/admin">Back to analytics</a>
    </div>
    <div class="grid">
        <section class="panel">
            <h2>Explainability Panel</h2>
            <p style="color:#cbd5e1;">The model flagged this transaction due to multiple risk signals. Review the feature contributions below.</p>
            <div class="spider">
                <div class="spider-bar"><span>Location Mismatch</span><strong>92%</strong></div>
                <div class="spider-fill"><div class="spider-fill-inner" style="width:92%;"></div></div>
                <div class="spider-bar"><span>Unusual Time</span><strong>78%</strong></div>
                <div class="spider-fill"><div class="spider-fill-inner" style="width:78%;"></div></div>
                <div class="spider-bar"><span>High Amount</span><strong>66%</strong></div>
                <div class="spider-fill"><div class="spider-fill-inner" style="width:66%;"></div></div>
                <div class="spider-bar"><span>New Payee</span><strong>84%</strong></div>
                <div class="spider-fill"><div class="spider-fill-inner" style="width:84%;"></div></div>
                <div class="spider-bar"><span>Rapid Transfers</span><strong>71%</strong></div>
                <div class="spider-fill"><div class="spider-fill-inner" style="width:71%;"></div></div>
            </div>
            <div class="chart">
                <h3>User History Trend</h3>
                <div class="chart-graph">User spending spike vs. normal behavior</div>
            </div>
        </section>
        <aside class="panel">
            <h2>Transaction summary</h2>
            <div class="detail-row">
                <div class="detail-card"><h3>Sender</h3><p>user@upi</p></div>
                <div class="detail-card"><h3>Receiver</h3><p>merchant@bank</p></div>
            </div>
            <div class="detail-row">
                <div class="detail-card"><h3>Amount</h3><p>₹12,450</p></div>
                <div class="detail-card"><h3>Risk Score</h3><p>87%</p></div>
            </div>
            <div class="detail-row">
                <div class="detail-card" style="grid-column: 1 / -1;"><h3>Status</h3><p style="color:#f87171;">Fraud Suspected</p></div>
            </div>
            <div class="actions">
                <button class="action-button action-block">Freeze Account</button>
                <button class="action-button action-safe">Allow Transaction</button>
                <button class="action-button action-otp">Send OTP Verification</button>
            </div>
        </aside>
    </div>
</div>
{% endblock %}
''',
    'check.html': '''{% extends 'base.html' %}
{% block title %}HYBRID MACHINE LEARNING MODEL FOR UPI FRAUD DETECTION{% endblock %}
{% block styles %}
<style>
    :root {
        --bg: #0f172a;
        --surface: #111827;
        --card: #1f2937;
        --text: #e2e8f0;
        --muted: #94a3b8;
        --success: #16a34a;
        --danger: #ef4444;
        --accent: #38bdf8;
        --border: rgba(148, 163, 184, 0.18);
    }
    * { box-sizing: border-box; }
    body {
        margin: 0;
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(180deg, #020617 0%, #0f172a 100%);
        color: var(--text);
    }
    .page { width: 100%; max-width: 960px; margin: 0 auto; padding: 32px 20px 60px; }
    .hero { margin: 32px 0; padding: 28px; border: 1px solid var(--border); border-radius: 24px; background: rgba(30, 41, 59, 0.88); box-shadow: 0 24px 80px rgba(15, 23, 42, 0.35); }
    .hero p { margin: 0; line-height: 1.8; color: var(--muted); }
    .grid { display: grid; gap: 24px; grid-template-columns: 1.2fr 0.8fr; }
    .card { background: var(--card); border: 1px solid var(--border); border-radius: 24px; padding: 24px; }
    .card h2 { margin-top: 0; margin-bottom: 16px; font-size: 1.5rem; }
    label { display: block; margin-bottom: 8px; color: var(--muted); font-size: 0.95rem; }
    input, select { width: 100%; padding: 14px 16px; margin-bottom: 18px; border-radius: 14px; border: 1px solid rgba(148, 163, 184, 0.25); background: #111827; color: var(--text); font-size: 1rem; }
    input::placeholder, select { color: var(--muted); }
    button { width: 100%; padding: 14px 18px; border: none; border-radius: 16px; background: var(--accent); color: #020617; font-weight: 700; cursor: pointer; transition: transform 0.2s ease, box-shadow 0.2s ease; }
    button:hover { transform: translateY(-1px); box-shadow: 0 14px 30px rgba(56, 189, 248, 0.28); }
    .status-box { padding: 16px; background: rgba(56, 189, 248, 0.12); border: 1px solid rgba(56, 189, 248, 0.24); border-radius: 16px; color: var(--text); margin-bottom: 20px; }
    .result-card { padding: 20px; border-radius: 20px; border: 1px solid rgba(148, 163, 184, 0.2); background: rgba(30, 41, 59, 0.95); min-height: 200px; }
    .result-card h3 { margin-top: 0; font-size: 1.2rem; }
    .result-status { margin: 16px 0; font-size: 1.2rem; font-weight: 700; }
    .result-status.safe { color: var(--success); }
    .result-status.fraud { color: var(--danger); }
    .progress { width: 100%; height: 14px; border-radius: 999px; background: rgba(148, 163, 184, 0.15); overflow: hidden; margin-top: 12px; }
    .progress-bar { height: 100%; width: 0; background: linear-gradient(90deg, #38bdf8, #0ea5e9); border-radius: 999px; transition: width 0.35s ease; }
    .legal { margin-top: 24px; font-size: 0.9rem; color: var(--muted); line-height: 1.6; }
    .feature-list { display: grid; gap: 12px; margin-top: 20px; }
    .feature-item { display: flex; align-items: center; gap: 12px; padding: 16px; background: rgba(255,255,255,0.03); border: 1px solid rgba(148, 163, 184, 0.14); border-radius: 16px; }
    .feature-item span { width: 10px; height: 10px; border-radius: 999px; background: var(--accent); flex-shrink: 0; }
    @media (max-width: 860px) { .grid { grid-template-columns: 1fr; } }
</style>
{% endblock %}
{% block content %}
<section class="hero">
    <p>Submit payment details or upload a screenshot after a UPI payment completes. The system will analyze the transaction and flag suspicious activity.</p>
</section>
<div class="grid">
    <div class="card">
        <h2>Payment Verification</h2>
        {% if not model_ready %}
        <div class="status-box">Model initialization is in progress or dummy models are being generated. Wait a moment and refresh if needed.</div>
        {% endif %}
        <label for="transaction_id">Transaction ID</label>
        <input id="transaction_id" placeholder="e.g. TXN123456789" />
        <label for="amount">Transaction Amount</label>
        <input id="amount" type="number" step="0.01" placeholder="Enter amount in INR" />
        <label for="upi_id">UPI ID</label>
        <input id="upi_id" placeholder="example@bank" />
        <label for="payer_name">Payer Name</label>
        <input id="payer_name" placeholder="Sender name" />
        <label for="payee_name">Payee Name</label>
        <input id="payee_name" placeholder="Receiver name" />
        <label for="category">Payment Type</label>
        <select id="category">
            <option value="transfer">Transfer</option>
            <option value="payment">Payment</option>
            <option value="refund">Refund</option>
            <option value="withdrawal">Withdrawal</option>
            <option value="deposit">Deposit</option>
            <option value="upi">UPI</option>
            <option value="p2p">P2P</option>
        </select>
        <label for="remarks">Payment Remarks</label>
        <input id="remarks" placeholder="Enter note or transaction remark" />
        <label for="screenshot">Upload payment screenshot (optional)</label>
        <input id="screenshot" type="file" accept="image/*" />
        <button id="submitBtn" onclick="check()" type="button">Verify Payment</button>
        <div id="result" class="result-card">
            <h3>Result preview</h3>
            <p class="muted">Submit a transaction to view the fraud verdict and risk score.</p>
            <div id="resultText"></div>
            <div class="progress" hidden>
                <div id="scoreBar" class="progress-bar"></div>
            </div>
            <p id="resultHint" class="legal"></p>
        </div>
    </div>
    <div class="card">
        <h2>Why this matters</h2>
        <div class="feature-list">
            <div class="feature-item"><span></span><div>Hybrid scoring from deep learning and random forest.</div></div>
            <div class="feature-item"><span></span><div>Designed for UPI transaction monitoring.</div></div>
            <div class="feature-item"><span></span><div>Instant evaluation in a user-friendly dashboard.</div></div>
            <div class="feature-item"><span></span><div>Logs every check into a local SQLite database.</div></div>
        </div>
        <p class="legal">The goal is to simulate a production-ready fraud check portal for UPI transactions. This interface is built to resemble a real-life analytics dashboard.</p>
    </div>
</div>
{% endblock %}
{% block scripts %}
<script>
    const resultText = document.getElementById('resultText');
    const scoreBar = document.getElementById('scoreBar');
    const progress = document.querySelector('.progress');
    const submitBtn = document.getElementById('submitBtn');
    const resultHint = document.getElementById('resultHint');

    function check() {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Verifying...';
        resultText.textContent = 'Analyzing payment...';
        resultText.className = '';
        progress.hidden = true;
        resultHint.textContent = '';

        const formData = new FormData();
        formData.append('transaction_id', document.getElementById('transaction_id').value);
        formData.append('amount', document.getElementById('amount').value);
        formData.append('upi_id', document.getElementById('upi_id').value);
        formData.append('payer_name', document.getElementById('payer_name').value);
        formData.append('payee_name', document.getElementById('payee_name').value);
        formData.append('category', document.getElementById('category').value);
        formData.append('remarks', document.getElementById('remarks').value);
        const screenshotFile = document.getElementById('screenshot').files[0];
        if (screenshotFile) { formData.append('screenshot', screenshotFile); }

        fetch('/api/check', { method: 'POST', body: formData })
            .then(async response => {
                const data = await response.json();
                if (!response.ok) throw new Error(data.error || 'Unexpected error');
                return data;
            })
            .then(data => {
                const isFraud = data.result === 'FRAUD';
                resultText.textContent = `${data.result} — Score ${data.score.toFixed(4)}`;
                resultText.className = isFraud ? 'result-status fraud' : 'result-status safe';
                scoreBar.style.width = `${Math.min(Math.max(data.score * 100, 4), 100)}%`;
                scoreBar.style.background = isFraud ? '#ef4444' : '#22c55e';
                progress.hidden = false;
                resultHint.textContent = data.note || '';
            })
            .catch(error => {
                resultText.textContent = error.message;
                resultText.className = 'result-status fraud';
                resultHint.textContent = 'Please provide valid payment details and try again.';
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Verify Payment';
            });
    }
</script>
{% endblock %}
'''
}

root = Path('templates')
root.mkdir(exist_ok=True)
for name, html in new_templates.items():
    path = root / name
    path.write_text(html, encoding='utf-8')
print('Templates updated:', ', '.join(sorted(new_templates.keys())))
